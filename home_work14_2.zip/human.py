class Human:
    """
    Клас опису людини

    Attributes:
        gender (str): cтать
        age (int): вік
        first_name (str): ім'я
        last_name (str): прізвище
    """

    def __init__(self, gender: str, age: int, first_name: str, last_name: str):
        """
        Ініціалізує екземпляр класу Human

        Parameters:
            gender (str): стать
            age (int): вік
            first_name (str): ім'я
            last_name (str): прізвище
        """
        self.gender = gender
        self.age = age
        self.first_name = first_name
        self.last_name = last_name

    def __str__(self) -> str:
        """
        Повертає представлення об'єкта Human у str.

        Returns:
            str: інформація про людину
        """
        return f"{self.first_name} {self.last_name}, Вік: {self.age}, {self.gender}"

