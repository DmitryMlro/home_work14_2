from student import Student
from group_error import GroupError


class Group:
    """
    Клас опису групи студентів з обмеженням на кількість студентів

    Attributes:
        number (str): номер групи
        group (set): студенти які є в групі
    """

    def __init__(self, number: str):
        """
        Ініціалізує екземпляр класу Group

        Parameters:
            number (str): номер групи
        """
        self.number = number
        self.group = set()
        self.max_size = 10

    def add_student(self, student: Student):
        """
        Додає студента до групи.

        Parameters:
            student (Student): об'єкт класу Student, який додається до групи

        Raises:
            GroupFullError: якщо група вже містить максимальну кількість студентів.
        """
        if len(self.group) >= self.max_size:
            raise GroupError()
        self.group.add(student)

    def delete_student(self, last_name: str):
        """
        Видаляє студента з групи за прізвищем

        Parameters:
            last_name (str): прізвище студента, якого потрібно видалити
        """
        student = self.find_student(last_name)
        if student:
            self.group.remove(student)

    def find_student(self, last_name: str) -> Student | None:
        """
        Знаходить студента по прізвищу

        Parameters:
            last_name (str): прізвище студента

        Returns:
            Student | None: об'єкт класу Student - якщо знайдений, або None
        """
        for student in self.group:
            if student.last_name == last_name:
                return student
        return None

    def __str__(self) -> str:
        """
        Повертає представлення об'єкта Group у str

        Returns:
            str: інформація про групу та студентів у ній
        """
        all_students = "\n".join(str(student) for student in self.group)
        return f"Номер групи: {self.number}\nСтуденти:\n{all_students}"
