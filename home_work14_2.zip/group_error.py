class GroupError(Exception):
    """
    Виняток, що виникає при спробі додати до групи більше ніж 10 студентів
    """

    def __str__(self):
        return "Група заповнена! (max 10)"

