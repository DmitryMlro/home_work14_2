from human import Human


class Student(Human):
    """
    Клас опису студента, успадкований від класу Human

    Attributes:
        record_book (str): номер студентського квитка
    """

    def __init__(self, gender: str, age: int, first_name: str, last_name: str, record_book: str):
        """
        Ініціалізує екземпляр класу Student

        Параметри:
            gender (str): стать студента
            age (int): вік студента
            first_name (str): ім'я студента
            last_name (str): прізвище студента
            record_book (str): номер студентського квитка
        """
        super().__init__(gender, age, first_name, last_name)
        self.record_book = record_book

    def __str__(self) -> str:
        """
        Повертає представлення об'єкта Student у str

        Returns:
            str: інформація про студента
        """
        return f"Студент: {super().__str__()}, Студ. квиток: {self.record_book}"

    def __eq__(self, other):
        if isinstance(other, Student):
            return str(self) == str(other)
        return False

    def __hash__(self):
        return hash(str(self))